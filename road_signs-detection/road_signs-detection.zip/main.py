import pyimagesearch.learning_data as id
import pyimagesearch.predict as pd
import tree
import matplotlib.pyplot as plt
from mlxtend.plotting import plot_decision_regions

while(True):
    print("MENU")
    print("1 - uczenie\n2 - rozpoznawanie\n3 - pokaz wykres\n4 - wyjscie\n")
    choice = input()

    if(choice == '1'):
        id.gen_data()
        Tree, X, Y = tree.gen_tree()
    elif(choice == '2'):
        pd.prediction(Tree)
    elif (choice == '3'):
        plt.figure(2)
        plot_decision_regions(X, Y, Tree)
        plt.xlabel("Kolor")
        plt.ylabel("Ksztalt")
        plt.show()
    elif(choice == '4'):
        break
    else:
        print("Nie ma takiej opcji\n")

